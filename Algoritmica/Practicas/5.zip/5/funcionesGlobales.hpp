//============================================================================
// Algoritmica
// Name        : funcionesGlobales.hpp
// Author      : Manuel Casas Castro (i72cascm)
// Fecha       : 10/12/2022
//============================================================================

#ifndef _FUNCIONESGLOBALES_H_
#define _FUNCIONESGLOBALES_H_

#include <vector>

using namespace std;

bool Lugar(int k, vector < int > X);

#endif