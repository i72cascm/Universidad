Esta práctica esta realizada tras la práctica 8, por lo que se ha procedido a quitar la parte del código que permitia a la serpiente moverse.

La explicación de la práctica esta contenido en el pdf de la práctica 8.
