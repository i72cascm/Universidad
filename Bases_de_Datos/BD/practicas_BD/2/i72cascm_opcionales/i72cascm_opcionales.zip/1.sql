--Ejercicio 1--

select dni 
from votantes 
where telefono 
like '%6%6%' and telefono not like '%6%6%6%';