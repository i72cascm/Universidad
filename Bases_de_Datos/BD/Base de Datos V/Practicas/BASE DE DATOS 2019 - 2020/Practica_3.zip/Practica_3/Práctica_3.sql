--Ejercicio 1:
SELECT votantes.nombrecompleto
FROM votantes
WHERE votantes.dni LIKE CONCAT('%', (votantes.localidad + 1));

--Ejercicio 2:
SELECT votantes.nombrecompleto, localidades.nombre, DECODE(votantes.localidad, 1, 'Madrid', 2, 'Madrid', 3, 'Madrid', localidades.nombre)
FROM votantes, localidades
WHERE votantes.localidad = localidades.idlocalidad;

--Ejercicio 3:
SELECT partidos.siglas
FROM partidos, eventos_resultados
WHERE partidos.idpartido = eventos_resultados.partido
HAVING COUNT(eventos_resultados.partido) > (SELECT AVG(COUNT(eventos_resultados.partido)) FROM eventos_resultados GROUP BY eventos_resultados.partido)
GROUP BY partidos.siglas;

--Ejercicio 4: NOTA: doble subconsulta
SELECT votantes.dni
FROM votantes
WHERE votantes.fechanacimiento = (SELECT MIN(votantes.fechanacimiento) FROM votantes 
WHERE votantes.fechanacimiento > (SELECT MIN(votantes.fechanacimiento) FROM votantes));

--Ejercicio 5:
SELECT consultas.votante "Votante", COUNT(consultas.votante) "Conteo"
FROM consultas
GROUP BY consultas.votante
ORDER BY "Conteo" DESC;

--Ejercicio 6:
SELECT consultas.votante "Votante", COUNT(consultas.votante) "Conteo"
FROM consultas
HAVING COUNT(consultas.votante) > (SELECT AVG(COUNT(consultas.votante)) FROM consultas GROUP BY consultas.votante)
GROUP BY consultas.votante
ORDER BY "Conteo" DESC;

--Ejercicio 7:
SELECT votantes.nombrecompleto
FROM votantes, consultas
WHERE votantes.dni = consultas.votante
HAVING COUNT(consultas.votante) > (SELECT AVG(COUNT(consultas.votante)) FROM consultas GROUP BY consultas.votante)
GROUP BY votantes.nombrecompleto;

--Ejercicio 8:
SELECT consultas.votante "Votante", COUNT(consultas.votante) "Conteo"
FROM consultas, votantes
WHERE votantes.dni = consultas.votante
AND votantes.dni <> (SELECT votantes.dni FROM votantes WHERE votantes.fechanacimiento = (SELECT MIN(votantes.fechanacimiento) FROM votantes WHERE votantes.fechanacimiento > (SELECT MIN(votantes.fechanacimiento) FROM votantes)))
GROUP BY consultas.votante
ORDER BY "Conteo" DESC;

--Ampliacion
--Ejercicio 1:  revisar CON DECODE
SELECT SUBSTR(nombrecompleto,1,INSTR(nombrecompleto,' ')) "Nombre", localidades.nombre "Localidad", provincias.nombre "Provincia"
FROM votantes, localidades, provincias
WHERE votantes.localidad = localidades.idlocalidad
AND localidades.provincia = provincias.idprovincia;

--Ejercicio 2:  revisar
SELECT localidades.nombre  || ' va antes que ' || 
(SELECT localidades.nombre FROM localidades WHERE localidades.idlocalidad = 
(SELECT localidades.idlocalidad + 1 FROM localidades 
ORDER BY localidades.idlocalidad ASC)
ORDER BY localidades.idlocalidad ASC) "Ordenacion"
FROM localidades
ORDER BY localidades.idlocalidad ASC;

--Ejercicio 3:
SELECT DISTINCT localidades.nombre "Localidad", localidades.numerohabitantes "Habitantes"
FROM localidades
WHERE localidades.numerohabitantes >
(SELECT MIN(localidades.numerohabitantes) FROM localidades WHERE localidades.idlocalidad > 
(SELECT votantes.localidad
FROM votantes
WHERE votantes.fechanacimiento = (SELECT MIN(votantes.fechanacimiento) FROM votantes 
WHERE votantes.fechanacimiento > (SELECT MIN(votantes.fechanacimiento) FROM votantes))))
ORDER BY localidades.numerohabitantes ASC;

--Ejercicio 4:
SELECT nombrecompleto "Nombre", localidad "Localidad",
  CASE
    WHEN fechanacimiento < '01/01/2002' THEN 'Mayor Edad'
    ELSE 'Menor Edad' END "Mayoria Edad"
FROM votantes
WHERE localidad = 2 OR localidad = 4 OR localidad = 8
ORDER BY fechanacimiento;

--Ejercicio 5:
SELECT localidades.nombre, localidades.numerohabitantes, provincias.comunidad
FROM localidades, provincias
WHERE (localidades.provincia = provincias.idprovincia)
AND (localidades.provincia = 1 OR localidades.provincia = 2 OR localidades.provincia = 3)
AND (localidades.numerohabitantes > (SELECT localidades.numerohabitantes FROM localidades WHERE localidades.idlocalidad = 4));

--Ejercicio 6: REVISAR
SELECT votantes.nombrecompleto
FROM votantes

--Ejercicio 7: REVISAR
SELECT localidades.nombre "Localidad", DECODE(votantes.estudiossuperiores, 'Ninguno', 1, 'Basicos', 2, 'Superiores', 3, 'Doctorado', 4) "Estudios"
FROM localidades, votantes
WHERE localidades.idlocalidad = votantes.localidad
ORDER BY "Estudios" ASC;
