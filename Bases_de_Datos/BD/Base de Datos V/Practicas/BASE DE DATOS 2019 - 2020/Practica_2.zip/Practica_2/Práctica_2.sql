--Ejercicio 1:
SELECT votantes.nombrecompleto
FROM votantes
WHERE nombrecompleto LIKE '%n';

--Ejercicio 2:
SELECT votantes.dni
FROM votantes
WHERE dni LIKE '%5%5%5%';

--Ejercicio 3:
SELECT votantes.nombrecompleto
FROM votantes
WHERE fechanacimiento > '01/01/1990';

--Ejercicio 4:
SELECT votantes.nombrecompleto, localidades.nombre
FROM votantes, localidades
WHERE localidades.idlocalidad = votantes.localidad 
AND localidades.numerohabitantes > 300000;

--Ejercicio 5:
SELECT votantes.nombrecompleto, provincias.comunidad
FROM votantes, provincias, localidades
WHERE votantes.localidad = localidades.idlocalidad
AND localidades.provincia = provincias.idprovincia
AND localidades.numerohabitantes > 300000;

--Ejercicio 6: 
SELECT partidos.idpartido "Partido", COUNT(consultas_datos.consulta) "Conteo"
FROM partidos, consultas_datos
WHERE partidos.idpartido = consultas_datos.partido
GROUP BY partido
ORDER BY partido;
--NOTA: ORDER BY TIENE QUE IR AL FINAL.

--Ejercicio 8:
SELECT partidos.nombrecompleto
FROM partidos, consultas_datos
WHERE partidos.idpartido = consultas_datos.partido
HAVING COUNT(consultas_datos.consulta) > 10
GROUP BY partidos.nombrecompleto;

--Ejercicio 9:
SELECT partidos.nombrecompleto, COUNT(consultas_datos.consulta) "Conteo"
FROM partidos, consultas_datos
WHERE partidos.idpartido = consultas_datos.partido
HAVING COUNT(consultas_datos.consulta) > 10
GROUP BY partidos.nombrecompleto;

--Ejercicio 10:
SELECT partidos.nombrecompleto, COUNT(consultas_datos.consulta) "Conteo"
FROM partidos, consultas_datos
WHERE partidos.idpartido = consultas_datos.partido
AND consultas_datos.respuesta LIKE 'Si'
AND consultas_datos.certidumbre > 0.8
GROUP BY partidos.nombrecompleto;


--Ampliacion:
--Ejercicio 1: Obtener el DNI de todos los votantes que tengan dos 6s en su telefono pero contemplar que no tienen mas de tres
SELECT votantes.dni, votantes.telefono "Prueba"
FROM votantes
WHERE votantes.telefono LIKE '%6%6%'
AND votantes.telefono NOT LIKE '%6%6%6%';

--Ejercicio 2: Obtener el DNI de todos los votantes que tengan tres 6s en su telefono pero contemplar que no tienen mas de tres, dos de ellos deben estar juntos
SELECT votantes.dni, votantes.telefono "Prueba"
FROM votantes
WHERE votantes.telefono LIKE '%6%6%6%'
AND votantes.telefono NOT LIKE '%6%6%6%6%';

--Ejercicio 3: Mostrar aquella localidad cuyo numero de habitantes acaba igual que su numero de provincia, mostrando tambien el nombre de la provincia a la que pertenece
--REVISAR
SELECT localidades.nombre "Localidad", provincias.nombre "Provincia"
FROM localidades, provincias
WHERE localidades.provincia = provincias.nombre
AND localidades.numerohabitantes LIKE '%_' || provincias.idprovincia;

--Ejercicio 4: Mostrar el nombre completo de los votantes cuyo telefono acaba igual que su dni
SELECT votantes.nombrecompleto
FROM votantes
WHERE votantes.telefono LIKE '%_' || votantes.dni;
--REVISAR

--Ejercicio 5: Mostrar el nombre completo de aquellos votantes que contienen al menos una 'S' y cuya fecha de nacimiento es anterior al 12 de Febrero de 1990
SELECT votantes.nombrecompleto, votantes.fechanacimiento "Prueba"
FROM votantes
WHERE votantes.nombrecompleto LIKE '%s%'
AND votantes.fechanacimiento < '12/02/1990';

--Ejercicio 6: Usar el operador DISTINCT (http://www.w3schools.com/sql/sql_distinct.asp). Obtener todos los votantes que han participado en alguna consulta. Dichos votantes deben aparecer en orden decreciente de dni
SELECT DISTINCT consultas.votante
FROM consultas
ORDER BY consultas.votante DESC;

--Ejercicio 7: Mostrar el dni de aquellos votantes que han participado en mas de tres consultas
SELECT consultas.votante, COUNT(consultas.votante) "Prueba: Consultas"
FROM consultas
HAVING COUNT(consultas.votante) > 3
GROUP BY consultas.votante;

--Ejercicio 8: Mostrar el nombre completo de los votantes que han participado en mas de tres consultas y especificar en cuantas consultas participaron (en orden creciente)
SELECT consultas.votante, COUNT(consultas.votante) "Prueba: Consultas"
FROM consultas
HAVING COUNT(consultas.votante) > 3
GROUP BY consultas.votante
ORDER BY "Prueba: Consultas" ASC;

--Ejercicio 9: Obtener el nombre de los votantes y el nombre de su localidad para aquellos votantes que han sido consultados en una localidad que tiene mas de 300000 habitantes
SELECT DISTINCT consultas.votante, localidades.nombre "Localidad"
FROM consultas, votantes, localidades
WHERE consultas.votante = votantes.dni
AND votantes.localidad = localidades.idlocalidad
AND localidades.numerohabitantes > 300000;
--REVISAR

--Ejercicio 10: Mostrar el nombre de cada partido politico y la maxima certidumbre que tiene para sus consultas
SELECT partidos.nombrecompleto, MAX(consultas_datos.certidumbre) "Maxima certidumbre"
FROM partidos, consultas_datos
WHERE partidos.idpartido = consultas_datos.partido
GROUP BY partidos.nombrecompleto;

--Ejercicio 11: Mostrar el nombre del votante y su certidumbre media en todas las consultas en las que ha respondido de manera afirmativa
SELECT votantes.nombrecompleto, AVG(consultas_datos.certidumbre) "Certidumbre media"
FROM votantes, consultas_datos, consultas
WHERE votantes.dni = consultas.votante
AND consultas.idconsulta = consultas_datos.idrecogida
AND consultas_datos.respuesta = 'Si'
GROUP BY votantes.nombrecompleto;

--Ejercicio 12: Mostrar el nombre del votante y su certidumbre media en todas las consultas en las que ha respondido de manera afirmativa UNICAMENTE para aquellos votantes cuyo certidumbre media esta entre 0'5 y 0'8
SELECT votantes.nombrecompleto, AVG(consultas_datos.certidumbre) "Certidumbre media"
FROM votantes, consultas_datos, consultas
WHERE votantes.dni = consultas.votante
AND consultas.idconsulta = consultas_datos.idrecogida
AND consultas_datos.respuesta = 'Si'
HAVING AVG(consultas_datos.certidumbre) < 0.8
AND AVG(consultas_datos.certidumbre) > 0.5
GROUP BY votantes.nombrecompleto;

--Ejercicio 13: Mostrar el nombre de los partidos y la certidumbre media obtenida para cada partido considerando solo aquellas consultas en las que el encuestado ha contestado negativamente a votar a dicho partido y con una certidumbre significativa (por encima del 60%)
SELECT partidos.nombrecompleto, AVG(consultas_datos.certidumbre)
FROM partidos, consultas_datos
WHERE partidos.idpartido = consultas_datos.partido
AND consultas_datos.respuesta = 'No'
AND consultas_datos.certidumbre > 0.6
GROUP BY partidos.nombrecompleto;